﻿namespace QueryBuilderStarter
{
    public interface IClassModell
    {
        public int Id { get; set; }
    }
}